/*
 * Public API Surface of alinma-global
 */

export * from './lib/alinma-global.service';
export * from './lib/alinma-global.component';
export * from './lib/alinma-global.module';
export * from './lib/components/button/button.component';
