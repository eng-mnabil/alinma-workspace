import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-alinma-global',
  template: `
    <p>
      alinma-global works!
    </p>
  `,
  styles: [
  ]
})
export class AlinmaGlobalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
